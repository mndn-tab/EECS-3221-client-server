/***********************************************************************/
/**      Author: Minas Spetsakis                                      **/
/**        Date: June 2021                                            **/
/** Description: Skeleton for Assgn. II                               **/
/***********************************************************************/

#include <stdio.h>
#include <sys/time.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>

#include "queue.h"
#include "args.h"
#include "error.h"

int njobs,			/* number of jobs ever created */
  ttlserv,			/* total service offered by servers */
  ttlqlen;			/* the total qlength */
int nblocked;			/* The number of threads blocked */

/***********************************************************************
                           r a n d 0 _ 1
************************************************************************/
double rand0_1(unsigned int *seedp)
{
  double f;
  /* We use the re-entrant version of rand */
  f = (double)rand_r(seedp);
  return f/(double)RAND_MAX;
}


/***********************************************************************
                             C L I E N T
************************************************************************/

void *client(void *vptr)
{
  unsigned int seed;
  int pthrerr;
  struct thread_arg *ptr;

  ptr = (struct thread_arg*)vptr;

  while (1)
    {
    }
  return NULL;
      
}

/***********************************************************************
                             S E R V E R
************************************************************************/

void *server(void *vptr)
{
  int busy;
  int pthrerr;
  struct thread_arg *ptr;

  ptr = (struct thread_arg*)vptr;

  busy = 0;
  while (1)
    {
    }
  return NULL;
}


/***********************************************************************
                                C L K
************************************************************************/

void *clk(void *vptr)
{
  int tick;
  int pthrerr;
  struct thread_arg *ptr;

  ptr = (struct thread_arg*)vptr;

  printf("Average waiting time:    %f\n",(float)ttlqlen/(float)njobs);
  printf("Average turnaround time: %f\n",(float)ttlqlen/(float)njobs+
	 (float)ttlserv/(float)njobs);
  printf("Average execution time:  %f\n",(float)ttlserv/(float)njobs);
  printf("Average queue length: %f\n",(float)ttlqlen/(float)ptr->nticks);
  printf("Average interarrival time time: %f\n",(float)ptr->nticks/(float)njobs);
  /* Here we die with mutex locked and everyone else asleep */
  exit(0);
}

int main(int argc, char **argv)
{
  int pthrerr, i;
  int nserver, nclient, nticks;
  float lam, mu;

  pthread_t server_tid, client_tid;
  pthread_cond_t sthrblockcond, sclkblockcond;
  pthread_mutex_t sblocktex, sstatex;
  struct thread_arg *allargs;
  pthread_t *alltids;


  ttlserv  = 0;
  ttlqlen  = 0;
  nblocked = 0;
  njobs    = 0;

  nserver = 2;
  nclient = 2;
  lam = 0.005;
  mu = 0.01;
  nticks = 1000;
  i=1;
  while (i<argc-1)
    {
      if (strncmp("--lambda",argv[i],strlen(argv[i]))==0)
	  lam     = atof(argv[++i]);
      else if (strncmp("--mu",argv[i],strlen(argv[i]))==0)
	  mu      = atof(argv[++i]);
      else if (strncmp("--servers",argv[i],strlen(argv[i]))==0)
	  nserver = atoi(argv[++i]);
      else if (strncmp("--clients",argv[i],strlen(argv[i]))==0)
	  nclient = atoi(argv[++i]);
      else if (strncmp("--ticks",argv[i],strlen(argv[i]))==0)
	  nticks  = atoi(argv[++i]);
      else
	fatalerr(argv[i], 0, "Invalid argument\n");
      i++;
    }
  if (i!=argc)
    fatalerr(argv[0], 0, "Odd number of args\n");

  allargs = (struct thread_arg *)
    malloc((nserver+nclient+1)*sizeof(struct thread_arg));
  if (allargs==NULL)
    fatalerr(argv[0], 0,"Out of memory\n");
  alltids = (pthread_t*)
    malloc((nserver+nclient)*sizeof(pthread_t));
  if (alltids==NULL)
    fatalerr(argv[0], 0,"Out of memory\n");

  exit(-1);
}
