extern void fatalerr(char *name, int lerrno, char *mssg);
